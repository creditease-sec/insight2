#!usr/bin/env python
#-*- coding:utf-8 -*-

def main(*args, **kwargs):
    # args 是系统设置应用此扩展的内容, 比如应用资产应用此扩展，调用时会将应用资产内容放到这个参数里
    # kwargs 是coonfig.json 中配置的参数，上传扩展之后可以在洞察中进行输入配置
    ip = kwargs.get("iplist")

    # TODO
    """
    可以进行输入参数进行安全检查
    """

